//Require Modules
const express = require('express');
const morgan = require('morgan');
const storyRoutes = require('./routes/storyRoutes')


//Create Application
const app = express();


//Configure App
let port = 3000;
let host = 'localhost';
app.set('view engine', 'ejs');


//Mount middleware
app.use(express.static('public'));
app.use(express.urlencoded({extended: true}));
app.use(morgan('tiny'));

//Set up routes
app.get('/', (req, res) => {
    res.render('index');
})

app.use('/stories', storyRoutes);

//Start Server
app.listen(port, host, () => {
    console.log('Server is running on port', port)
})